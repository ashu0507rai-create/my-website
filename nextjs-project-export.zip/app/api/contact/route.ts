import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, email, projectType, message } = body;

    if (!name || !email || !message) {
      return NextResponse.json(
        { error: "Name, email, and message fields are required." },
        { status: 400 }
      );
    }

    // Process contact submission (e.g. log or forward to CRM/webhook)
    console.log("Contact submission received:", { name, email, projectType, message });

    return NextResponse.json(
      {
        success: true,
        message: "Thank you for reaching out! Our team will contact you shortly.",
        timestamp: new Date().toISOString(),
      },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Internal Server Error processing request." },
      { status: 500 }
    );
  }
}
